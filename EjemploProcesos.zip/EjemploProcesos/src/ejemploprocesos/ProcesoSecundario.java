package ejemploprocesos;

/**
 *
 * @author CrisGC
 */
public class ProcesoSecundario {
    public static void main(String[] args) {
        System.out.println("Proceso secundario...");
        System.exit(103);
    }
}
