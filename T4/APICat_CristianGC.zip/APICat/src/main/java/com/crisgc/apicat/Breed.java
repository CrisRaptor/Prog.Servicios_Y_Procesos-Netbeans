/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.crisgc.apicat;

/**
 *
 * @author CrisGC
 */
public class Breed {

    Weight WeightObject;
    private String id;
    private String name;
    private String vetstreet_url;
    private String temperament;
    private String origin;
    private String country_codes;
    private String country_code;
    private String description;
    private String life_span;
    private float indoor;
    private float lap;
    private String alt_names;
    private float adaptability;
    private float affection_level;
    private float child_friendly;
    private float dog_friendly;
    private float energy_level;
    private float grooming;
    private float health_issues;
    private float intelligence;
    private float shedding_level;
    private float social_needs;
    private float stranger_friendly;
    private float vocalisation;
    private float experimental;
    private float hairless;
    private float natural;
    private float rare;
    private float rex;
    private float suppressed_tail;
    private float short_legs;
    private String wikipedia_url;
    private float hypoallergenic;
    private String reference_image_id;
}
