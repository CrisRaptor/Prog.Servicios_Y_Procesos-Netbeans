/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.crisgc.apicat;

import java.util.ArrayList;

/**
 *
 * @author CrisGC
 */
public class Breeds {
    private ArrayList<Breed> breeds;

    public ArrayList<Breed> getBreeds() {
        return breeds;
    }

    public void setBreeds(ArrayList<Breed> breeds) {
        this.breeds = breeds;
    }
    
    
}
