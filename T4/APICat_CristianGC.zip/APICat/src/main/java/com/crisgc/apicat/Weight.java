/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.crisgc.apicat;

/**
 *
 * @author CrisGC
 */
public class Weight {

    private String imperial;
    private String metric;
}
