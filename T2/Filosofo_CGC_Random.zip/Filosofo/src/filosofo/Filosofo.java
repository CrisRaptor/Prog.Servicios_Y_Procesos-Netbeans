package filosofo;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Filosofo extends Thread {

    private Mesa mesa;
    private int comensal;

    public Filosofo(Mesa m, int comensal) {
        this.mesa = m;
        this.comensal = comensal;
    }

    public void run() {
        pensando();     
        while (true) {
            mesa.cogerTenedores(comensal);
            comiendo();
        }
    }

    public void pensando() {
        System.out.println("Filosofo " + comensal + " piensa");
        try {
            //Piensa entre 1900 y 2500ms (con saltos de 100ms)
            Thread.sleep((((int) Math.random() * 7 + 1) * 100) + 1800);
        } catch (InterruptedException ex) {
            System.out.println("Error al comer");
        }
    }

    public void comiendo() {
        System.out.println("Filosofo " + comensal + " come");
        try {
            //Come entre 1400 y 2000ms (con saltos de 100ms)
            Thread.sleep((((int) Math.random() * 7 + 1) * 100) + 1300);
        } catch (InterruptedException ex) {
            System.out.println("Error al comer");
        }
        mesa.dejarTenedores(comensal);
        pensando();
    }
}
